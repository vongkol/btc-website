<?php

return [
    'logout' => 'Logout',
    'home' => 'Home',
    'about' => "About Us",
    'history' => "Our Histroy",
    'vision' => "Vision, Mission, Core Values",
    'chart' => "Organizational Chart",
    'where_we_work' => "Where We Work",
    'board' => "BOD Members", 
    'staff' => "Staff",
    'report' => "Annual & Financial Reports",
    'our_program' => "Our Programs",
    'youth_participation' => "Youth Participation in Decision-Making Processes",
    'youth_employment' => "Youth Employment Opportunities",
    'involve' => "Get Involved",
    'case_study' => "Case Study",
    'event' => "Events",
    'job' => "Job Announcements",
    'volunteer' => "Volunteer With Us",
    'elibrary' => "E-Library",
    'ebook' => "E-Books",
    'province_office' => "Provincial Offices",
    'hq' => "Head Office in Phnom Penh",
    'contact' => "Contact Us"
];