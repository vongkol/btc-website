@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header text-bold">
                    <i class="fa fa-align-justify"></i> New Member&nbsp;&nbsp;
                    <a href="{{url('/admin/membership/')}}" class="btn btn-link btn-sm">
                        Back
                    </a>
                </div>
                <div class="card-block">

                </div>
            </div>
        </div>
    </div>
@endsection