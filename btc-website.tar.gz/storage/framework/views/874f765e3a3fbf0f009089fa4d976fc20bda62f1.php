<?php $__env->startSection('content'); ?>
<style>
    p, div{
        color: #000;
    }
</style>
<button type="button" id="sidebarCollapse" class="btn btn-dark">
    <i class="fa fa-bars mr-8"></i> 
    <span>Request Payment</span>
</button>
<hr>
<div class="row">
    <div class="col-sm-12">
            <?php if(Session::has('sms1')): ?>
            <div class="alert alert-danger" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div>
                    <?php echo e(session('sms1')); ?>

                </div>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(url('/request/submit')); ?>" method="POST" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

            <div class="form-group row">
                <label for="" class="col-sm-3">Your Total Earning</label>
                <div class="col-sm-9 text-danger">
                    <strong>$ <?php echo e($user->score); ?></strong>
                </div>
            </div>
            <div class="form-group row">
                <label for="" class="col-sm-3">Request Amount <span class="text-danger">*</span></label>
                <div class="col-sm-9">
                    <input type="number" name="score" id='score' required>
                </div>
            </div>
            <div class="form-group row">
                <label for="" class="col-sm-3">&nbsp;</label>
                <div class="col-sm-9">
                    <button class="btn btn-primary btn-sm" type="submit">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function(){
            $("#menu>li").removeClass('active');
            $("#menu_earning").addClass('active');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>