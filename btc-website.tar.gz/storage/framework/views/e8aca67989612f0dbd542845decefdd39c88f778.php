<?php $__env->startSection('content'); ?>
<section class="pricing-plane-area page-plan section_padding_100_90 clearfix" id="pricing">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-heading text-center">
                    <h2 class="text-plan text-white">Warning!</h2>
                    <div class="line-shape"></div>
                </div>
            </div>
        </div>
       
    </div>
</section>
<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <p></p>
                <h1 class="text-danger text-center">
                    You already have a plan. You cannot buy a new plan, please contact to the support!
                </h1>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>