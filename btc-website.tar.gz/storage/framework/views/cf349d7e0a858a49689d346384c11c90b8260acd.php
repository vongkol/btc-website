<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <i class="fa fa-align-justify"></i> Edit News&nbsp;&nbsp;
                    <a href="<?php echo e(url('/admin/news/')); ?>" class="btn btn-link btn-sm">
                        Back
                    </a>
                </div>
                <div class="card-block">
                    <?php if(Session::has('sms')): ?>
                        <div class="alert alert-success" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('sms1')): ?>
                        <div class="alert alert-danger" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div>
                                <?php echo e(session('sms1')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(url('/admin/news/update')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($news->id); ?>">
                        <div class="row">
                            <div class="col-sm-8">
                                <div class="form-group row">
                                    <label for="" class="col-sm-2">Title <span class="text-danger">*</span></label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" required name="title" value="<?php echo e($news->title); ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-sm-2">Short Description</label>
                                    <div class="col-sm-10">
                                        <textarea name="short_description" id="short_description" 
                                        cols="30" rows="3" class="form-control"><?php echo e($news->short_description); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div>
                                    <input type="file" class="form-control" name="photo" onchange="loadFile(event)">
                                </div>
                                <P></P>
                                <img src="<?php echo e(asset('uploads/news/'.$news->featured_image)); ?>" alt="" class="imimage" id="img" width="120">
                            </div>
                        </div>
                       <div class="row">
                           <div class="col-sm-12">
                               <strong>Description</strong>
                               <textarea name="description" id="description" 
                               cols="30" rows="10" class="form-control"><?php echo e($news->description); ?></textarea>
                               <P></P>
                               <button class="btn btn-primary" type="submit">Save</button>
                           </div>
                       </div>
                    </form>
                </div>
                
            </div>
        </div>
        <!--/.col-->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    function loadFile(e){
        var output = document.getElementById('img');
        output.src = URL.createObjectURL(e.target.files[0]);
    }
</script>
<script src="<?php echo e(asset('js/ckeditor/ckeditor.js')); ?>"></script>
<script type="text/javascript">
   var roxyFileman = "<?php echo e(asset('fileman/index.html?integration=ckeditor')); ?>"; 

  CKEDITOR.replace( 'description',{filebrowserBrowseUrl:roxyFileman, 
                               filebrowserImageBrowseUrl:roxyFileman+'&type=image',
                               removeDialogTabs: 'link:upload;image:upload'});
</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>