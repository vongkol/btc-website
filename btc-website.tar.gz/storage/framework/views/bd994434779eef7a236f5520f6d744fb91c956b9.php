<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <i class="fa fa-align-justify"></i> Payment List
                  
                </div>
                <div class="card-block">

                    <table class="tbl">
                        <thead>
                            <tr>
                                <th>&numero;</th>
                                <th>Request Date</th>
                                <th>Customer Name</th>
                                <th>Customer Email</th>
                                <th>Score</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $pagex = @$_GET['page'];
                                if(!$pagex)
                                $pagex = 1;
                                $i = 18 * ($pagex - 1) + 1;
                            ?>
                          <?php $__currentLoopData = $pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/admin/payment/detail/'.$p->id)); ?>"><?php echo e($p->request_date); ?></a>
                                </td>
                                <td><?php echo e($p->first_name); ?> <?php echo e($p->last_name); ?></td>
                                <td><?php echo e($p->email); ?></td>
                                <td>$ <?php echo e($p->score); ?></td>
                                <td><?php echo e($p->status==1?'Approved':'Pending'); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/admin/payment/delete/'.$p->id)); ?>" class="text-danger" onclick="return confirm('You want to delete?')">Delete</a>
                                </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table><br>
                    <?php echo e($pays->links()); ?>

                </div>
            </div>
        </div>
        <!--/.col-->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>