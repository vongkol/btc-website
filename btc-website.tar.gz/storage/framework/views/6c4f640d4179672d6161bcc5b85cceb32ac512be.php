
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <i class="fa fa-align-justify"></i> Social List&nbsp;&nbsp;
                    <a href="<?php echo e(url('/social/create')); ?>" class="btn btn-link btn-sm">New</a>
                </div>
                <div class="card-block">

                    <table class="tbl">
                        <thead>
                            <tr>
                                <th>&numero;</th>
                                <th>Icon</th>
                                <th>Name</th>
                                <th>URL</th>
                                <th>Order &numero;</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php ($i=1); ?>
                            <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><img src="<?php echo e(URL::asset('uploads/socials/'.$soc->icon)); ?>" width="40"/></td>
                                    <td><?php echo e($soc->name); ?></td>
                                    <td><?php echo e($soc->url); ?></td> 
                                    <td><?php echo e($soc->order_number); ?></td>
                                    <td>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(url('/social/edit/'.$soc->id)); ?>" title="Edit"><i class="fa fa-pencil"></i></a>
                                        <a class="btn btn-xs btn-danger" href="<?php echo e(url('/social/delete/'.$soc->id)); ?>" onclick="return confirm('Do you want to delete?')" title="Delete"><i class="fa fa-trash-o"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($socials->links()); ?>

                </div>
            </div>
        </div>
        <!--/.col-->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>